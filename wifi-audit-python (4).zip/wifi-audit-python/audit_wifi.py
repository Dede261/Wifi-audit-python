#!/usr/bin/env python3
"""Pemeriksa informasi jaringan lokal untuk pembelajaran dan audit yang diizinkan."""
import json
import platform
import socket
import subprocess
from datetime import datetime, timezone
from pathlib import Path

def command_output(command):
    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=5, check=False)
        if result.returncode == 0:
            return (result.stdout or "").strip() or None
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        pass
    return None

def get_local_ip():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        # Memilih antarmuka lokal; tidak mengirim data aplikasi ke alamat ini.
        sock.connect(("192.0.2.1", 80))
        return sock.getsockname()[0]
    except OSError:
        try:
            return socket.gethostbyname(socket.gethostname())
        except OSError:
            return None
    finally:
        sock.close()

def get_gateway():
    system = platform.system().lower()
    if system == "linux":
        output = command_output(["ip", "route", "show", "default"])
        if output:
            parts = output.split()
            if "via" in parts:
                return parts[parts.index("via") + 1]
        output = command_output(["sh", "-c", "cat /proc/net/route"])
        if output:
            for line in output.splitlines()[1:]:
                fields = line.split()
                if len(fields) > 2 and fields[1] == "00000000":
                    try:
                        return socket.inet_ntoa(bytes.fromhex(fields[2])[::-1])
                    except (ValueError, OSError):
                        pass
    elif system == "darwin":
        output = command_output(["route", "-n", "get", "default"])
        if output:
            for line in output.splitlines():
                if "gateway:" in line:
                    return line.split("gateway:", 1)[1].strip()
    return None

def get_wifi_summary():
    if "android" in platform.platform().lower():
        return "Android terdeteksi; detail Wi-Fi mungkin dibatasi izin sistem."
    if platform.system().lower() == "linux":
        output = command_output(["nmcli", "-t", "-f", "ACTIVE,SSID", "dev", "wifi"])
        if output:
            for line in output.splitlines():
                if line.startswith("yes:"):
                    return {"ssid": line[4:]}
    return "Nama Wi-Fi tidak tersedia pada lingkungan ini."

def check_internet():
    try:
        socket.getaddrinfo("example.com", 443, type=socket.SOCK_STREAM)
        return True
    except OSError:
        return False

def main():
    report = {
        "waktu_utc": datetime.now(timezone.utc).isoformat(),
        "sistem": platform.platform(),
        "hostname": socket.gethostname(),
        "ip_lokal": get_local_ip(),
        "gateway": get_gateway(),
        "ringkasan_wifi": get_wifi_summary(),
        "dns_internet_tersedia": check_internet(),
        "catatan": "Gunakan hanya pada perangkat/jaringan milik sendiri atau yang diizinkan audit."
    }
    print("=== WiFi Audit Python ===")
    print(json.dumps(report, indent=2, ensure_ascii=False))
    output = Path("laporan_audit.json")
    output.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"\nLaporan tersimpan di: {output.resolve()}")

if __name__ == "__main__":
    main()
