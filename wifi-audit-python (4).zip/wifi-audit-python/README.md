# WiFi Audit Python

Skrip Python sederhana untuk memeriksa informasi dasar jaringan pada perangkat sendiri.

## Fitur
- Menampilkan IP lokal dan hostname.
- Mencoba mendeteksi gateway default.
- Memeriksa resolusi DNS untuk koneksi internet.
- Menyimpan hasil ke `laporan_audit.json`.
- Tidak mengambil kata sandi Wi-Fi, memindai perangkat lain, atau melakukan eksploitasi.

## Menjalankan di Android dengan Termux

Pasang Termux dari sumber tepercaya, lalu jalankan:

```sh
pkg update
pkg install python git
git clone https://github.com/USERNAME/wifi-audit-python.git
cd wifi-audit-python
python audit_wifi.py
```

Ganti `USERNAME` dengan nama akun GitHub Anda.

Jika belum mengunggah repository, letakkan `audit_wifi.py` di satu folder lalu jalankan `python audit_wifi.py`.

## Catatan
Android dapat membatasi akses ke SSID dan detail jaringan tergantung versi Android, izin aplikasi, dan lingkungan Termux. Gateway atau SSID mungkin tidak tersedia. Skrip ini hanya membaca informasi dasar dan melakukan pemeriksaan DNS.
